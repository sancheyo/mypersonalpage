function myFunction() {
    const myWindow = window.open("YYSanchez_Resume-project.pdf", "YYSanchez_Resume-project.pd", "width=300,height=300");
    myWindow.opener.document.getElementById().innerHTML = "HELLO";
  }